class Processo {
    int id;
    String nome;
    int prioridade; // 1-Alta, 2-Média, 3-Baixa
    int ciclos;
    boolean precisaDisco;   // se o processo precisa de disco
    boolean jaPediuDisco;   // controla se já bloqueou 1x pelo disco

    Processo(int id, String nome, int prioridade, int ciclos, boolean precisaDisco) {
        this.id = id;
        this.nome = nome;
        this.prioridade = prioridade;
        this.ciclos = ciclos;
        this.precisaDisco = precisaDisco;
        this.jaPediuDisco = false;
    }

    @Override
    public String toString() {
        return "[ID: " + id + ", Nome: " + nome +
                ", Prioridade: " + prioridade +
                ", Ciclos restantes: " + ciclos +
                ", PrecisaDisco=" + precisaDisco +
                ", JaPediu=" + jaPediuDisco + "]";
    }
}


class ListaDeProcessos {
    No tail;
    int tamanho;

    boolean estaVazia() {
        return tamanho == 0;
    }

    void adicionar(Processo p) {
        No novo = new No(p);
        if (tail == null) {
            tail = novo;
            tail.prox = tail;
        } else {
            novo.prox = tail.prox;
            tail.prox = novo;
            tail = novo;
        }
        tamanho++;
    }

    Processo executar() {
        if (estaVazia()) return null;

        No atual = tail.prox;
        Processo p = atual.processo;

        if (atual == tail) {
            tail = null;
        } else {
            tail.prox = atual.prox;
        }
        tamanho--;
        return p;
    }
}

class ListaEncadeada {
    No head;

    void adicionar(Processo p) {
        No novo = new No(p);
        if (head == null) {
            head = novo;
        } else {
            No aux = head;
            while (aux.prox != null) {
                aux = aux.prox;
            }
            aux.prox = novo;
        }
    }

    Processo removerPrimeiro() {
        if (head == null) return null;
        Processo p = head.processo;
        head = head.prox;
        return p;
    }

    boolean estaVazia() {
        return head == null;
    }

    void imprimir() {
        if (head == null) {
            System.out.println("Nenhum processo nesta lista.");
            return;
        }
        No aux = head;
        while (aux != null) {
            System.out.println(aux.processo);
            aux = aux.prox;
        }
    }
}







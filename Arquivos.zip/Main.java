import java.util.Random;
class main {
    public static void main(String[] args) {
        Scheduler scheduler = new Scheduler();
        Random rand = new Random(42);

        // Comando para criar 10 processos aleatóriossrc
        for (int i = 1; i <= 10; i++) {
            int prioridade = rand.nextInt(3) + 1;
            int ciclos = rand.nextInt(5) + 2;
            boolean precisaDisco = rand.nextBoolean();
            Processo p = new Processo(i, "P" + i, prioridade, ciclos, precisaDisco);
            scheduler.adicionarProcesso(p);
        }

        System.out.println("=== Início da execução ===");
        while (scheduler.temProcessosAtivos()) {
            scheduler.executarCicloDeCPU();
        }

        System.out.println("\n=== Processos finalizados ===");
        scheduler.lista_finalizados.imprimir();
    }
}
class No {
    Processo processo;
    No prox;

    No(Processo p) {
        this.processo = p;
    }
}
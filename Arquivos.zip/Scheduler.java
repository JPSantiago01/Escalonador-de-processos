import java.util.Random;

    class Scheduler {
        ListaDeProcessos lista_alta_prioridade = new ListaDeProcessos();
        ListaDeProcessos lista_media_prioridade = new ListaDeProcessos();
        ListaDeProcessos lista_baixa_prioridade = new ListaDeProcessos();

        ListaEncadeada lista_bloqueados = new ListaEncadeada();
        ListaEncadeada lista_finalizados = new ListaEncadeada();

        int contador_ciclos_alta_prioridade = 0;
        Random rand = new Random();

        void adicionarProcesso(Processo p) {
            if (p.prioridade == 1) lista_alta_prioridade.adicionar(p);
            else if (p.prioridade == 2) lista_media_prioridade.adicionar(p);
            else lista_baixa_prioridade.adicionar(p);
        }

        void executarCicloDeCPU() {
            // 1) Desbloqueia no início do ciclo
            if (!lista_bloqueados.estaVazia()) {
                Processo desbloqueado = lista_bloqueados.removerPrimeiro();
                System.out.println(" Processo " + desbloqueado.nome +
                        " foi DESBLOQUEADO e voltou para prioridade " +
                        desbloqueado.prioridade);
                adicionarProcesso(desbloqueado);
            }

            // 2) Seleciona processo
            Processo proc = null;

            if (contador_ciclos_alta_prioridade < 5 && !lista_alta_prioridade.estaVazia()) {
                proc = lista_alta_prioridade.executar();
                contador_ciclos_alta_prioridade++;
            } else {
                if (!lista_media_prioridade.estaVazia()) {
                    proc = lista_media_prioridade.executar();
                } else if (!lista_baixa_prioridade.estaVazia()) {
                    proc = lista_baixa_prioridade.executar();
                }
                contador_ciclos_alta_prioridade = 0;
            }

            if (proc == null) return;

            // 3) Verifica se precisa de disco e ainda não pediu
            if (proc.precisaDisco && !proc.jaPediuDisco) {
                proc.jaPediuDisco = true; // marca que já bloqueou pelo disco
                System.out.println(" Processo " + proc.nome + " pediu acesso ao DISCO e foi BLOQUEADO.");
                lista_bloqueados.adicionar(proc);
                return; // não executa neste ciclo
            }

            // 4) Executa normalmente
            System.out.println("⚙ Executando " + proc);

            proc.ciclos--;

            if (proc.ciclos > 0) {
                // chance de bloqueio genérico (20%)
                if (rand.nextInt(100) < 20) {
                    System.out.println(" Processo " + proc.nome + " foi BLOQUEADO.");
                    lista_bloqueados.adicionar(proc);
                } else {
                    adicionarProcesso(proc);
                }
            } else {
                System.out.println(" Finalizando " + proc.nome);
                lista_finalizados.adicionar(proc);
            }
        }

        boolean temProcessosAtivos() {
            return !(lista_alta_prioridade.estaVazia() &&
                    lista_media_prioridade.estaVazia() &&
                    lista_baixa_prioridade.estaVazia() &&
                    lista_bloqueados.estaVazia());
        }
    }


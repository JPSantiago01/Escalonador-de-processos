# Escalonador-de-processos
Simulação de escalonador de processos com múltiplas filas de prioridade em Java.
